import { UserState, UserActions } from './slices/userSlice';
import { PatientState, PatientActions } from './slices/patientSlice';
import { SettingsState, SettingsActions } from './slices/settingsSlice';
import { PaymentState, PaymentActions } from './slices/paymentSlice';
import { AppointmentState, AppointmentActions } from './slices/appointmentSlice';

export type StoreState = UserState & PatientState & SettingsState & PaymentState & AppointmentState &
  UserActions & PatientActions & SettingsActions & PaymentActions & AppointmentActions;

export interface StoreMigrations {
  [key: number]: (state: Partial<StoreState>) => Partial<StoreState>;
}